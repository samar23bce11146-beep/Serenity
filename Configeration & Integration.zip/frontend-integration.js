/* =============================================================
   frontend-integration.js
   ─────────────────────────────────────────────────────────────
   Paste this into your existing script.js to connect the
   Serenity frontend to the backend API.

   Replace the TODO block in your modeButtons click handler
   with the code below.
   ============================================================= */

const API_BASE = 'http://localhost:5000/api'; // Change to your deployed URL later

/*
  Call this when a mode button is clicked.
  It sends the selected mode to the backend and receives a recommendation.
*/
async function startSession(mode) {
  try {
    const response = await fetch(`${API_BASE}/sessions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode })
      // Later you can also send: checkIn: { stressLevel, energyLevel, sleepLastNight }
    });

    if (!response.ok) throw new Error('Server error');

    const data = await response.json();

    // data contains:
    // {
    //   sessionId: "...",
    //   mode: "exam",
    //   recommendation: {
    //     title: "Pre-Exam Calm & Focus",
    //     message: "...",
    //     techniques: [...],
    //     duration: "5–8 minutes"
    //   },
    //   createdAt: "..."
    // }

    // Save session ID so you can retrieve it later
    sessionStorage.setItem('serenity_session_id', data.sessionId);

    // Display the recommendation (see displayRecommendation below)
    displayRecommendation(data.recommendation);

    console.log('[Serenity] Session started:', data);
    return data;

  } catch (err) {
    console.error('[Serenity] Failed to start session:', err);
  }
}

/*
  Renders the recommendation in the #begin section.
  You can style .serenity-recommendation in your style.css.
*/
function displayRecommendation(rec) {
  const beginSection = document.getElementById('begin');
  if (!beginSection) return;

  // Remove existing recommendation if present
  const existing = beginSection.querySelector('.serenity-recommendation');
  if (existing) existing.remove();

  const html = `
    <div class="serenity-recommendation" style="
      margin-top: 24px;
      background: rgba(255,255,255,0.55);
      backdrop-filter: blur(14px);
      border: 1px solid rgba(255,255,255,0.7);
      border-radius: 20px;
      padding: 32px;
      max-width: 520px;
      text-align: left;
    ">
      <p style="font-size:0.75rem;text-transform:uppercase;letter-spacing:0.08em;color:#8aab94;font-weight:500;margin-bottom:8px;">
        Your Session
      </p>
      <h3 style="font-family:'Fraunces',serif;font-weight:300;font-size:1.4rem;margin-bottom:12px;color:#2c3a30;">
        ${rec.title}
      </h3>
      <p style="font-size:0.92rem;color:#4a5e50;line-height:1.7;margin-bottom:20px;">
        ${rec.message}
      </p>
      <ul style="list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:16px;">
        ${rec.techniques.map(t => `
          <li style="display:flex;gap:10px;align-items:flex-start;font-size:0.875rem;color:#4a5e50;">
            <span style="color:#8aab94;flex-shrink:0;margin-top:1px;">✦</span>
            <span>${t}</span>
          </li>
        `).join('')}
      </ul>
      <p style="font-size:0.78rem;color:#8aab94;font-weight:500;">
        ⏱ Suggested duration: ${rec.duration}
      </p>
    </div>
  `;

  beginSection.querySelector('.placeholder-section__inner').insertAdjacentHTML('beforeend', html);

  // Scroll smoothly to the begin section
  beginSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

/*
  ── Replace the mode button click handler in your script.js ──

  Find this block in script.js:
    btn.addEventListener('click', () => {
      ...
      console.log(`[Serenity] Mode selected: ${mode}`);
      // TODO: launch the appropriate therapy session for the selected mode
    });

  And add one line:
    startSession(mode);   ← ADD THIS
*/
